# CS207 Homework Assignment #2
# November 23, 2023
# Name: Sardor Akhmedjonov
# NetID: sa524
# compiled on Macbook Pro 2021 with M1 Chip
# Used Visual Studio Code with Jupyter Notebook

